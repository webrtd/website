<?php

class Solvease_Roles_Capabilities_Deactivator {

	public static function deactivate() {

	}

}
